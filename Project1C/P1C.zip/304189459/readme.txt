We met all of the project criteria that the Spec told us to do. 
We have 4 input pages and two browsing pages.
We do have a search php page, but we the search page as a search bar that is always on top of the page.
Our project passed all 5 test cases.

We divided the work between the Input pages and Search/browsing pages. 
We can improve by not procrastinating and putting the project until the last minute. This way we can work on the project on our free time instead being forced to work on it due to the deadline.