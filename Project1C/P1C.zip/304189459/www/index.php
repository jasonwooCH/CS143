<html>
<body>

<div id="navbar">
<!-- Wanna implement a persistent search bar here -->
	<div id="searchbar">
		<form method="POST" action="search.php" name="SearchBar">
			<input type="text" name="search">
			<input type="submit" value="Search" name="submit">
		</form>
	</div>

</div>

<a href=input.php> Click here to Add to our Database! </a><br>
<a href=actorbrowse.php> Click here to Show Actor Info! </a><br>
<a href=moviebrowse.php> Click here to Show Movie Info! </a><br>

</body>
</html>